# MCU Debug Assistant V0.4.22 - High Performance

V0.4.22 removes the temporary Stall-diagnosis instrumentation after the observed long pauses were traced to running the application under the VS Code Python debugger.

The release path keeps the optimizations that directly improve Scope performance: Ring Buffer preallocation, Render Cache, Single-ViewBox Stacked mode, Transform Follow, acquisition/render decoupling, bounded statistics refresh, and the live latency guard.

Removed from the hot path:
- GUI heartbeat WatchDog thread and stack sampling.
- Async diagnostic-file writer and `logs/scope_diagnostics_*` output.
- `debugpy` / `pydevd` detection and PERF warnings.
- Event-loop probe / rescue timer.
- presentation-gap / stall / worker / paint / append / setData / hover timing profilers.
- worker `scope_perf` signal and periodic profiling emissions.
- high-frequency persistent presentation polling.

Presentation is again driven by one `PreciseTimer` in single-shot mode. `PresentationPacer` uses absolute floating-point deadlines so 144 FPS is represented by an efficient 6/7 ms delay pattern without a second timer or catch-up bursts.

Run normally with:

```bat
run.bat
```

For meaningful frame-rate validation, launch the program normally rather than through an instrumenting Python debugger.
