from pathlib import Path
import time

from core.async_diagnostics import AsyncDiagnosticWriter


def test_async_diagnostic_writer(tmp_path: Path):
    path = tmp_path / "scope_diag.log"
    writer = AsyncDiagnosticWriter(path)
    assert writer.write("first line")
    assert writer.write("second line\nstack detail")
    writer.close(timeout=1.0)
    text = path.read_text(encoding="utf-8")
    assert "first line" in text
    assert "second line" in text
    assert "stack detail" in text
