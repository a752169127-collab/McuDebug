# V0.4.22 - High Performance Cleanup

- Removed all temporary Stall investigation instrumentation after the long pauses were attributed to VS Code/debugpy execution.
- Removed `GuiHeartbeatWatchdog`, `AsyncDiagnosticWriter`, debugger detection, event-loop probe/rescue timer, verbose Stall logs, and worker-side Scope timing telemetry.
- Removed paint/render/follow/setData/table/hover/append timing counters from the GUI hot path.
- Restored a single-shot `PreciseTimer` presentation clock driven by absolute `PresentationPacer` deadlines; no persistent oversampling timer and no secondary rescue timer.
- Kept the performance architecture that is independent of diagnostics: Ring Buffer preallocation, Render Cache, Transform Follow, Single-ViewBox Stacked mode, acquisition/render decoupling, capped heavy-curve refresh, and `LiveLatencyGuard`.
- Simplified Scope startup logging to user-relevant state only.

The high-refresh performance path should be evaluated with a normal Python launch, not VS Code F5/debugpy.
