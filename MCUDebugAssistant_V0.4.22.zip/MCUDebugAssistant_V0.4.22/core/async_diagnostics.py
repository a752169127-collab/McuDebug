from __future__ import annotations

"""Low-overhead asynchronous diagnostic file writer.

High-refresh GUI diagnostics must not dump long watchdog stack traces into a
QPlainTextEdit while Scope is live.  The widget/document layout can itself
become a source of native Qt event-loop work and turn a small scheduling pause
into a much larger secondary stall.  This writer moves verbose diagnostics to
a daemon I/O thread; the GUI receives only compact summary lines.
"""

from datetime import datetime
from pathlib import Path
from queue import Empty, Full, Queue
import threading
import time


class AsyncDiagnosticWriter:
    def __init__(self, path: str | Path | None = None, *, max_queue: int = 256) -> None:
        if path is None:
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = Path.cwd() / "logs" / f"scope_diagnostics_{stamp}.log"
        self.path = Path(path)
        self._queue: Queue[str | None] = Queue(maxsize=max(8, int(max_queue)))
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._dropped = 0
        self._lock = threading.Lock()
        self._start()

    def _start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="ScopeDiagnosticWriter", daemon=True)
        self._thread.start()

    @property
    def dropped(self) -> int:
        with self._lock:
            return int(self._dropped)

    def write(self, text: str) -> bool:
        if not text:
            return True
        self._start()
        try:
            self._queue.put_nowait(str(text))
            return True
        except Full:
            with self._lock:
                self._dropped += 1
            return False

    def close(self, timeout: float = 0.5) -> None:
        if self._stop.is_set():
            return
        self._stop.set()
        try:
            self._queue.put_nowait(None)
        except Full:
            pass
        thread = self._thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=max(0.0, float(timeout)))

    def _run(self) -> None:
        handle = None
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            handle = self.path.open("a", encoding="utf-8", buffering=1)
            while True:
                try:
                    item = self._queue.get(timeout=0.25)
                except Empty:
                    if self._stop.is_set():
                        break
                    continue
                if item is None:
                    break
                stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
                handle.write(f"[{stamp}] {item.rstrip()}\n")
        except Exception:
            # Diagnostics must never be allowed to crash or block the real-time
            # application.  Failure is intentionally silent here; callers can
            # still inspect the in-GUI compact summary.
            pass
        finally:
            if handle is not None:
                try:
                    handle.flush()
                    handle.close()
                except Exception:
                    pass
