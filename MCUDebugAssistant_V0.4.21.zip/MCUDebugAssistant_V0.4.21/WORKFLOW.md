# WORKFLOW.md — AI 自闭环开发工作流

```text
用户反馈 / Bug / 新需求
        ↓
01 Issue Intake
        ↓
02 建立复现条件
        ↓
03 读取项目状态与历史结论
        ↓
04 Instrument / Evidence
        ↓
05 Hypothesis Matrix
        ↓
06 技术方案
        ↓
07 实现
        ↓
08 compileall + pytest + regression
        ↓
09 版本打包
        ↓
10 用户实机验证
        ↓
11 自动更新项目记忆
        ↓
12 Release Report
        ↓
下一轮
```

## 每轮开发完自动更新

### PROJECT_STATE
当前版本、焦点、验证状态、Open Issues。

### ISSUE_LEDGER
记录：
- 症状
- 环境
- 证据
- 根因
- 修复
- 测试
- 最终状态

### VERSION_HISTORY
记录这一版为什么存在，而不是只写文件 diff。

### TEST_STATUS
自动测试与实机验证分开。

### ADR
架构发生变化才新增。

### LATEST_HANDOFF
写到足够让一个全新的 AI 直接继续工作。

### CHANGELOG
面向用户的版本变化。

## Release Gate

没有以下内容不应宣告版本完成：
- compile PASS
- pytest PASS
- state 更新
- issue 更新
- changelog 更新
- handoff 更新
- 明确 hardware validation 状态
