# ISSUE_LEDGER

## PERF-SCOPE-RELEASE-CLEANUP
Status: CODE_COMPLETE / PENDING_HARDWARE

### Version
V0.4.21

### Symptom
V0.4.20 kept the previous Stall investigation runtime enabled in the default
Scope path: watchdog and diagnostic-writer threads, a 25 ms Qt event-loop probe,
worker poll/read/decode timers, paint/presentation/stage counters and verbose
Stall classification logs.

### Expected behavior
Release Scope must keep acquisition, Ring Buffer, rendering and interaction
semantics while doing no continuous Stall investigation work by default.

### Root cause / evidence
- V0.4.18-V0.4.20 diagnostics remained wired unconditionally after the debugger
  environment was identified as a major source of event-loop disturbance.
- The 5 ms HSS poll performed poll/read/decode timing on every callback.
- Every presentation tick touched watchdog locks; a second GUI Timer fired every
  25 ms; every paint maintained FPS/jitter/percentile inputs.

### Fix
- Removed GUI watchdog, asynchronous diagnostic writer, event-loop probe,
  presentation-gap/starvation classification and debugger detection.
- Removed worker performance Signal and hot-path timing.
- Removed paint/render/follow/setData/table/hover/append telemetry and the
  diagnostic status line.
- Retained acquisition/presentation/hover product Timers, Actual Hz, Ring resize
  warning, LiveLatencyGuard and the complete Rendering V2 pipeline.

### Verification
- `compileall`: PASS
- `pytest`: 38 passed
- PySide6 offscreen ScopePage construction: PASS
- Default-release static cleanup regression: PASS
- Hardware RUN A/B: PENDING_HARDWARE

---

## PERF-QT-EVENTLOOP
Status: CLOSED_AS_DEBUG_DIAGNOSTIC

### Symptom
Scope occasionally experiences 100–900ms gaps.

### Evidence
In several logs:
- render/follow/setData/table/hover/append were sub-ms or low-ms,
- paint max was around low tens of ms,
- worker/read/decode were far below stall,
- ring resize = 0,
- watchdog classified GUI as `qt-native-event-loop`,
- Python stack showed `main.py -> app.exec()`,
- debugpy/pydevd was active.

### Conclusion
Current Scope Python functions cannot explain the full gap.
The default event-loop/watchdog investigation runtime was retired in V0.4.21.
This closure does not claim that a release-mode Qt stall can never occur.

---

## PERF-PRESENTATION-STARVATION
Status: CLOSED_AS_DEBUG_DIAGNOSTIC

### Symptom
Presentation can show a large gap while general Qt event-loop probe is less delayed.

### Direction
Prefer persistent precise presentation driver plus absolute deadline gating.
The persistent driver remains product code; timer-attribution diagnostics were
removed from the default Release path in V0.4.21.

---

## PERF-HOVER-ADJUSTSIZE
Status: FIXED

### Evidence
Watchdog stack captured:
`SignalProxy -> _mouse_moved -> _show_hover_at_host_pos -> hover_label.adjustSize()`

### Fix
Remove adjustSize from high-frequency mouse path, use cached geometry and throttled tooltip update.

---

## PERF-RING-RESIZE
Status: FIXED / DISPROVED_AS_CURRENT_STALL

Session ring preallocated.
Later logs:
`append ~0.1ms`, `resize=0`.

---

## PERF-GPU
Status: CLOSED

QOpenGLWidget viewport was not beneficial.
CPU Raster remains main path.

---

## HSS-ACTUAL-RATE
Status: OPEN

Observed example:
requested 1000Hz, actual ~496–499Hz
with GD32F425RG, SWD6000kHz, J-Link DLL V8.10, 3 channels.

Do not confuse acquisition throughput with GUI display reduction.
