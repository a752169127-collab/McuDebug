# LATEST_HANDOFF

## 当前版本
V0.4.21 — Release Scope diagnostic cleanup。

## 已完成
- 删除默认 ScopeGuiWatchdog 与异步诊断写线程。
- 删除 25 ms Qt event-loop probe、presentation gap/starvation 分类。
- 删除 debugpy/pydevd 检测与 PERF WARNING。
- 删除 Worker poll/read/decode、Paint、Render、Follow、setData、Table、Hover、Append 持续计时。
- 保留 J-Link 单 Owner、HSS/RTT 协议、Actual Hz、预分配 Ring Buffer、Persistent Presentation Driver、LiveLatencyGuard、Overlay/Stacked、Follow/Pause/Start/Export。

## 自动验证
- compileall PASS
- pytest 38 passed
- Python 3.14 / PySide6 6.11.2 offscreen ScopePage smoke PASS
- Confidence: VERIFIED_AUTOMATED

## 下一步
使用真实 J-Link 在 RUN 模式完成 V0.4.20 vs V0.4.21 A/B，记录设备、DLL、SWD、HSS/RTT、requested/actual Hz、通道、Buffer、Overlay/Stacked、Follow、FPS、FG/BG 和时长。

硬件状态：PENDING_HARDWARE。
