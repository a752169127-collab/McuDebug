# V0.4.21

## Release Scope hot-path cleanup

V0.4.21 retires the temporary Stall investigation runtime from the default
high-performance Scope path. It does not change HSS/RTT data, retained raw
samples, display transforms or user interaction semantics.

Removed:

- `ScopeGuiWatchdog` stack-sampling thread and classification logic.
- asynchronous `scope_diagnostics_*.log` writer thread.
- 25 ms Qt event-loop probe and presentation starvation/gap classification.
- debugpy/pydevd detection and `Scope PERF WARNING` logging.
- worker poll/read/decode performance Signal and continuous timing.
- Paint FPS, 1% low, jitter, paint max, render/follow/setData/table/hover/append
  stage timing and diagnostic status formatting.
- diagnostic-only/dead counters in PresentationPacer, Render Cache, Ring Buffer
  and Worker state.

Retained:

- single J-Link owner Worker and all connection/error protections.
- HSS timestamp and RTT-normal decoding.
- acquisition batching and Actual Hz.
- preallocated NumPy Ring Buffer, statistics, cursor/probe and CSV export.
- persistent PreciseTimer presentation driver and absolute deadline gate.
- CPU raster, Render Cache, peak-preserving reduction and logical-lane Stacked.
- Overlay/Stacked, Follow, Show, Pause, Start, View All, Gain/Offset and AXF rebind semantics.
- LiveLatencyGuard, hover coalescing and bounded/batched product logs.

## Verification

- `compileall`: PASS
- `pytest`: 38 passed
- default-release diagnostic cleanup regression: PASS
- Python 3.14 / PySide6 6.11.2 offscreen ScopePage smoke: PASS
- real J-Link/HSS/RTT validation: PENDING_HARDWARE

---

# V0.4.20

## Persistent Presentation Driver

V0.4.19 diagnostics showed that a long presentation gap does not always mean the entire Qt GUI event loop is blocked. In some traces the 25 ms Qt event-loop probe continued to run while the per-frame single-shot presentation timer did not fire for hundreds of milliseconds.

Changes:

- Replaced the per-frame single-shot `_viewport_timer` re-arm path with one persistent repeating `Qt.PreciseTimer`.
- Added a cheap absolute-deadline gate (`PresentationPacer.consume_due`) so the persistent driver never renders above the requested FPS.
- High-refresh targets use a 2~8 ms driver polling interval; idle/paused mode falls back to 50 ms.
- Removed all per-frame `QTimer.stop()/start()` and `next_delay_ms()` scheduling from `_viewport_tick()`.
- Missed deadlines skip directly to the next future slot; no catch-up render bursts.
- Added driver callback-rate telemetry (`D:` / `driverHz`).

## Stall attribution split

- Renamed the former generic `Scope GUI stall` concept to **presentation gap** in the V0.4.20 path.
- Qt event-loop stalls are independently detected by the 25 ms event-loop probe.
- Added **presentation starvation** detection when the Qt event loop is still healthy but presentation age exceeds the threshold.
- Starvation logs include timer active state, `remainingTime()`, persistent driver interval/rate, loop gap, target FPS and DBG/RUN environment.
- Status line now exposes `Gap:` and `PS:` separately.

## Tests

- Added persistent deadline-gate tests.
- Added missed-slot / no-catch-up-burst test.
- Added persistent driver interval tests.
- `compileall`: PASS
- `pytest`: 41 passed

---

# V0.4.19

## Non-invasive diagnostics / GUI log isolation

- Full watchdog stacks are written asynchronously to `logs/scope_diagnostics_*.log`.
- GUI Log receives compact summaries only.
- Log widget uses NoWrap, disabled undo/redo, 2000-block cap, and batched writes.
- Watchdog sampling is reduced under debugpy/pydevd.
