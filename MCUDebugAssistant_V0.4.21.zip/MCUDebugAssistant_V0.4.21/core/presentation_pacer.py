from __future__ import annotations

import math


class PresentationPacer:
    """Absolute-deadline presentation gate for a persistent Qt timer driver.

    V0.4.10-V0.4.19 re-armed a single-shot QTimer after every frame.  Under
    some Qt/Windows/debugger schedules the GUI event loop could remain alive
    while that one presentation timer was not delivered for hundreds of
    milliseconds.  V0.4.20 keeps a *repeating* PreciseTimer alive and uses this
    class only as an absolute-deadline gate.

    The persistent driver may wake more frequently than the requested display
    FPS.  ``consume_due(now)`` is intentionally cheap: it returns ``False``
    until the next floating-point deadline, and when late it skips missed slots
    rather than issuing catch-up bursts.
    """

    def __init__(self, fps: float = 60.0) -> None:
        self._fps = 60.0
        self._period_s = 1.0 / 60.0
        self._next_deadline: float | None = None
        self.set_fps(fps)

    @property
    def fps(self) -> float:
        return self._fps

    @property
    def period_s(self) -> float:
        return self._period_s

    def set_fps(self, fps: float) -> None:
        fps = max(1.0, float(fps))
        self._fps = fps
        self._period_s = 1.0 / fps
        self._next_deadline = None

    def reset(self, now: float | None = None) -> None:
        self._next_deadline = None if now is None else float(now) + self._period_s

    def consume_due(self, now: float) -> bool:
        """Return True once when the absolute presentation deadline is due.

        A late callback advances directly to the next future deadline. Missed
        display slots are never replayed as a burst.
        """
        now = float(now)
        period = self._period_s
        if self._next_deadline is None:
            self._next_deadline = now + period
            return False
        if now < self._next_deadline:
            return False

        lateness = max(0.0, now - self._next_deadline)
        missed = int(math.floor(lateness / period)) if period > 0 else 0
        self._next_deadline += (missed + 1) * period
        return True


def presentation_driver_interval_ms(fps: float, *, sampling: bool = True) -> int:
    """Choose a cheap persistent driver cadence for deadline polling.

    The driver is intentionally faster than the target FPS but does no render
    work unless ``PresentationPacer.consume_due`` returns True.  Around 144 Hz
    a 2 ms driver gives <=~2 ms deadline quantization without the 1000 callbacks/s
    cost of a 1 ms loop.  Lower refresh targets use a slower driver.  Idle mode
    falls back to 50 ms.
    """
    if not sampling:
        return 50
    fps = max(1.0, float(fps))
    period_ms = 1000.0 / fps
    # ~3-4 driver probes per presentation period, clamped for practical Qt use.
    return max(2, min(8, int(math.floor(period_ms / 3.0))))
