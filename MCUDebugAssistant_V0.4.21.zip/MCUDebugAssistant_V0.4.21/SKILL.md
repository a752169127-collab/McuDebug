# SKILL.md — MCU Debug Assistant 项目技能知识

## 项目定位

MCU Debug Assistant 是一个 Python 桌面 MCU 调试工具，目标体验接近：

**Keil Watch + J-Scope + AXF Symbol Browser**

主要技术：
- Python
- PySide6 / Qt
- pyqtgraph
- NumPy
- ctypes
- SEGGER J-Link DLL
- AXF / ELF / DWARF
- HSS / RTT

---

## 核心功能

### J-Link / Memory
- J-Link DLL 扫描
- x64 Python 优先 `JLink_x64.dll`
- SWD/JTAG
- Speed
- SEGGER 原生 Device Settings（兼容性需注意）
- `JLINK_ReadMemEx`
- `JLINK_WriteMemEx`
- Write + ReadBack Verify
- int8/uint8/int16/uint16/int32/uint32/int64/uint64/float/double

### Watch
- 多变量
- Current / Average / Min / Max
- Enter 写 Set Value
- 多选删除
- Average 以 Tab 分隔复制到 Excel
- AXF Reload Rebind
- Worker 采样/统计，GUI 低频 Snapshot

### AXF / ELF / DWARF
真实 ARMCC5 案例：
- ARM Compiler 5.06
- DWARF3
- `BlowerParamsObj = 0x20002894`
- `m_PosSpeed offset=132 -> 0x20002918`
- `m_Position offset=136 -> 0x2000291C`

ARMCC5 结构体成员关键：
`DW_AT_data_member_location = DW_FORM_block + DW_OP_plus_uconst`

Symbol Search 使用：
`QStandardItemModel + QSortFilterProxyModel + QTreeView + debounce`

### Scope
采样源：
- HSS
- RTT

功能：
- Overlay
- Stacked
- Sampling Request
- Actual Hz
- Buffer
- FPS
- Follow
- View All
- Show
- Start / Pause
- Gain / Offset
- Color
- Current / Avg / Min / Max
- Mouse Probe
- X1/X2/Y1/Y2
- CSV
- History Mode
- Interaction Mode
- Render Cache
- Ring Buffer

---

## 重要历史问题与结论

### HSS Timestamp Bug
HSS frame：
`[Timestamp U32][Payload]`

Timestamp 必须独立解析成 X，不能当 Channel Data。

### Watch 卡顿
原因：高频逐 Cell 更新。
解决：Worker Statistics + GUI Snapshot。

### Symbol Search 卡顿
原因：每个字符重建控件。
解决：Model/View + Proxy + debounce。

### Scope 长时间 Buffer 卡顿
旧：反复 concatenate。
后：Chunk Buffer，再到预分配 Ring Buffer。

### Zoom 后点变少
错误：
先对整个30s降采样，再看100ms。

正确：
先取需要范围，再 Peak-Preserve reduction。

### Stacked 性能
旧：
多个 PlotWidget / ViewBox / Axis。

演进：
单 GraphicsScene → Single ViewBox + Logical Lanes。

这个方向显著改善了 Stacked 流畅度。

### Lane Y 坐标
不要用整个30秒旧异常值决定当前局部 Lane Y Range。
实时/局部历史优先使用当前可见窗口。
`View All` 才使用整个 Buffer。

### GPU 实验
`QGraphicsView + QOpenGLWidget` 并不等于真正 GPU Scope。
实机反馈 CPU Raster 更流畅。
当前主路线：CPU Raster。
只有未来真正做 VBO/Shader Renderer 才重新评估 GPU。

### Hover Stall
Watchdog 曾明确抓到：
`SignalProxy -> _mouse_moved -> _show_hover_at_host_pos -> QLabel.adjustSize()`

所以高频 Mouse Move 中禁止做 Widget 动态布局/adjustSize。

### Ring Resize
实时 Ring Buffer 需要 Session Start 预分配。
如果日志显示 `resize=0`、append sub-ms，则 Ring resize 已经不是当前 Stall 原因。

### Debug Environment
高刷性能必须区分：
- `RUN`
- `DBG`

debugpy/pydevd 下的 Qt Timer/Event Loop 数据不能直接当 release performance。

---

## 当前 V0.4.x 技术演进

V0.4 重点从“功能实现”转为“Rendering V2”。

主要方向：
- Single Scene
- Ring Buffer
- Render Cache
- Single ViewBox Stacked
- Presentation Clock
- Curve Update 与 View FPS 分离
- Diagnostics / Watchdog
- Long-run stability

最近日志曾出现：
- 200~900ms presentation/GUI gap
- 但 render/follow/setData/table/append/paint/worker/read/decode 都远低于 stall
- watchdog 抓到 GUI 停在 `app.exec()`
- 环境存在 VS Code debugpy/pydevd

因此下一步必须优先：
1. RUN 模式 A/B
2. Qt Event Loop Gap
3. Presentation Timer Starvation
4. 持续 Timer Driver vs single-shot scheduling
5. cyclic Qt/Python object 生命周期单独分析

---

## 当前已排除/不应反复回退的假设

没有新证据不要重新把主要问题归因于：
- HSS decode 需要几百 ms
- 正常 Paint 需要几百 ms
- live ring resize
- hover adjustSize（修复后）
- 单纯“Python画不动”
- QOpenGLWidget 一定更快

需要用 instrumentation 重新证明才允许重开。
