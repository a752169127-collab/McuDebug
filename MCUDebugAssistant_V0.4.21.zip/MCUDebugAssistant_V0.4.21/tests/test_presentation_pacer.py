from core.presentation_pacer import PresentationPacer


def test_persistent_gate_emits_near_target_without_catchup_bursts():
    p = PresentationPacer(144)
    p.reset(0.0)
    fired = []
    # Simulate the persistent 2 ms driver used near 144 Hz.
    for i in range(1, 501):
        now = i * 0.002
        if p.consume_due(now):
            fired.append(now)
    assert 140 <= len(fired) <= 145


def test_persistent_gate_skips_missed_slots_after_pause():
    p = PresentationPacer(60)
    p.reset(0.0)
    assert not p.consume_due(0.010)
    assert p.consume_due(0.017)
    # A long external pause should produce one presentation, not catch-up spam.
    assert p.consume_due(0.200)
    assert not p.consume_due(0.201)
    assert not p.consume_due(0.202)


def test_driver_interval_is_persistent_poll_not_target_period():
    from core.presentation_pacer import presentation_driver_interval_ms

    assert presentation_driver_interval_ms(144, sampling=True) == 2
    assert presentation_driver_interval_ms(120, sampling=True) == 2
    assert 2 <= presentation_driver_interval_ms(60, sampling=True) <= 8
    assert presentation_driver_interval_ms(144, sampling=False) == 50
