# ARCHITECTURE

## Layer 1 — Device Interface
J-Link backend / session ownership。

## Layer 2 — Acquisition
Watch sampling / HSS / RTT / timestamp & payload decode。

## Layer 3 — Symbol
ELF / DWARF / symbol model / rebind。

## Layer 4 — Raw Data
Ring Buffer / stats / CSV / cursor source。

## Layer 5 — Display Preparation
Visible range / peak preserve / render cache / Gain Offset / lane mapping。

## Layer 6 — Presentation
Qt / pyqtgraph / Follow / Pan / Zoom / Cursor / Hover。

## Layer 7 — Optional Diagnostics
V0.4.21 默认 Release 不安装 Scope performance watchdog、诊断线程、
event-loop Timer 或 Worker/Paint 高频计时。未来诊断必须显式启用且默认关闭。

### 依赖原则
- Acquisition 不依赖具体 Widget。
- Raw Data 不被显示逻辑修改。
- Diagnostics 关闭时必须从热路径消失；不能只关闭日志输出。
