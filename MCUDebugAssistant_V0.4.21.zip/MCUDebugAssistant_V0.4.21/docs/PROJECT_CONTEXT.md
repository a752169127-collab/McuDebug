# PROJECT_CONTEXT

## Project
MCU Debug Assistant

## Goal
做一个可长期演进的 MCU 调试平台，核心体验接近 J-Scope + Keil Watch，并支持 AXF 自动符号、HSS/RTT、高速 Scope、长期性能诊断。

## 两条主数据链

```text
MCU
 ↓
J-Link
 ↓
JLinkWorker
 ↓
Acquisition
 ↓
Raw Buffer
 ├─ Statistics
 ├─ Cursor / Probe
 ├─ CSV
 └─ Display Pipeline
      ↓
   Scope
```

```text
AXF/ELF/DWARF
      ↓
Symbol Model
      ↓
Watch / Scope Channel Definition
```

## 当前成熟度
- J-Link Memory R/W：已实机验证
- Watch：较成熟
- AXF/ELF/DWARF：当前 ARMCC5 场景成熟
- Scope 功能：丰富
- Scope V0.4 Rendering V2：持续优化
- 高刷长时间稳定性：仍在诊断

## 当前晚期版本背景
V0.4.21 的开发结果：
- 保留 Persistent Precise Presentation Driver 与 Absolute Deadline Gate
- 删除默认 watchdog、event-loop probe、debugger detection 与高频 stage profiling
- Release Scope 默认路径只保留产品调度、保护与必要运行状态
- 正式性能仍只在 RUN 模式评价

如果实际源码版本更高，以仓库为准。
