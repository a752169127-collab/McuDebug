# MCU Debug Assistant V0.4.21

V0.4.21 is the clean Release Scope build. Temporary watchdog, event-loop,
debugger and stage-profiling code has been removed from the default execution
path while the mature V0.4 acquisition and Rendering V2 architecture remains.

## Presentation architecture

```text
Persistent Qt PreciseTimer Driver
        2~8 ms while live
              |
              v
PresentationPacer.consume_due(now)
              |
        not due -> return
              |
            due
              v
        _viewport_tick()
              |
     Render / Follow / Paint
```

The driver stays armed continuously. It is not stopped/restarted after every
frame. Target FPS is controlled by an absolute deadline, and missed deadlines
are skipped without catch-up render bursts.

Typical live driver intervals:

- 144 Hz target -> 2 ms persistent driver
- 120 Hz target -> 2 ms
- 90 Hz target -> 3 ms
- 60 Hz target -> about 5 ms
- idle/paused -> 50 ms

## Release diagnostics policy

The default Scope path creates no performance watchdog, diagnostic writer or
event-loop probe Timer. It also performs no continuous Worker/Paint/Render
stage timing. Future diagnostic instrumentation must be explicitly opt-in and
must install no Timer, thread or high-frequency counter while disabled.

## Rendering V2 behavior retained

- single J-Link owner Worker
- HSS/RTT acquisition batching and Actual Hz
- CPU raster renderer
- single-ViewBox logical-lane Stacked
- preallocated NumPy Ring Buffer
- Render Cache and peak-preserving visible-window reduction
- Transform Follow
- raw/display separation
- Show = visibility only
- Pause = retain data and view
- Start = new acquisition and clear prior session
- View All = complete retained buffer
- Gain/Offset = display only
- AXF/ELF/DWARF full-path rebind behavior
- fixed-geometry, throttled mouse Hover
- raw CSV export, statistics, cursor and probe

## Performance validation

For authoritative results, run outside VS Code F5/debugpy:

```text
run_performance.bat
```

or:

```text
python main.py
```

Do not use debugger results as Release performance evidence.
