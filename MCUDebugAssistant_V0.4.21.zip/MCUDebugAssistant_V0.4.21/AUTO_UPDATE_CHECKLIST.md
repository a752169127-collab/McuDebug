# AUTO_UPDATE_CHECKLIST

每轮开发结束必须检查：

- [ ] Version 已更新
- [ ] compileall PASS
- [ ] pytest PASS
- [ ] Targeted Regression Test
- [ ] Issue ID 已记录
- [ ] Issue 状态已更新
- [ ] Root Cause confidence 已记录
- [ ] DISPROVED hypotheses 已记录
- [ ] Performance environment 已记录
- [ ] Hardware validation 没有虚假声明
- [ ] CHANGELOG 更新
- [ ] PROJECT_STATE 更新
- [ ] ISSUE_LEDGER 更新
- [ ] VERSION_HISTORY 更新
- [ ] TEST_STATUS 更新
- [ ] LATEST_HANDOFF 更新
- [ ] ADR（如需要）更新
- [ ] 新版本包生成
- [ ] 最终答复包含下一步验证步骤
